def handler(request):
    return {"status": "healthy"}