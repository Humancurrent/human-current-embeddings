import json
import numpy as np

def handler(request):
    # Dummy embedding for testing
    vec = np.zeros(384).tolist()
    return {
        "status": "ok",
        "embedding": vec
    }
